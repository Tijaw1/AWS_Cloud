# AWS_Cloud

<<<<<<< HEAD
This program is a Robo Advisor built using Amazon lex and amazon lambda platforms. The program is meant to be an investment advisor. It takes in the customers personal information and risk appetite and recommends a portfolio that aligns with the customer requirements.

The test scripts are there to test the operation of the lambda function. 

The zipped files are the export files from amazon lex console:
 - Recommended portfolio is the export file for the intent.
 - Robo Advisor is the export file for the bot.
 - Risk Level is the export file for the slot types.
=======
![image](https://user-images.githubusercontent.com/74274975/111225232-c74c7080-859c-11eb-9f99-8728db4cd14b.png)


This is a simple robo advisor that could be used by existing customers or potential new customers to get investment portfolio recommendations for retirement.
In this activity, Amazon Web Services functions (amazon lex with amzon lambda) in combination with python has been used to to create a bot that will recommend an investment portfolio for a retirement plan.

Files: 

lambda_function.py
correct_dialog.txt
age_error.txt
incorrect_amount_error.txt
negative_age_error.txt
>>>>>>> b40109de6df6c99c7c901c42e44c3ecd31103454
